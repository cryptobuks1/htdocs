jQuery( function($){
    $('body').append('<div class="theme_customize_bg"><div class="theme_customize_message"></div></div>');
    $('.theme_customize_message').html('<p>Please activate theme and use link "Customize" for designing the template.</p>');
});