<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

theme_print_sidebar('default');
?>