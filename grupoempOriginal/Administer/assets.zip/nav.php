<?php 

if ($validar_acceso == "8456j95ygn894kfc9sdvfwe_qDDW_j5tyldk593w") { 

?>

<aside id="sidebar-left" class="sidebar-left">

				

					<div class="sidebar-header">

						<div class="sidebar-title">

							Menú de Navegación

						</div>

						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">

							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>

						</div>

					</div>

				

					<div class="nano">

						<div class="nano-content">

							<nav id="menu" class="nav-main" role="navigation">

								<ul class="nav nav-main">

                                	<li>

										<a href="banner_list.php">

											<i class="fa fa-file-image-o" aria-hidden="true"></i>

											<span>Slider</span>

										</a>

									</li>

									
                                     <li>

										<a href="post.php">

											<i class="fa fa-paper-plane-o" aria-hidden="true"></i>

											<span>Entradas</span>

										</a>

									</li>

									

                                    <li>

										<a href="album.php">

											<i class="fa fa-picture-o" aria-hidden="true"></i>

											<span>Galería Fotográfica</span>

										</a>

									</li>

									
                                   

                                    <li>

										<a href="admin.php">

											<i class="fa fa-lock" aria-hidden="true"></i>

											<span>Acceso Administrador</span>

										</a>

									</li>

								</ul>

							</nav>

				

							<hr class="separator" />

						</div>

				

					</div>

				

				</aside>

<?php } else { echo "Lo siento, no tienes permisos para acceder a este fichero."; }?>