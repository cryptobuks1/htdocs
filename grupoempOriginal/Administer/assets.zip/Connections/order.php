<?php
$cn = mysql_connect("localhost","alvar6_iprograme","Drako521");
mysql_select_db("alvar6_iprogramer", $cn);
?>