<?php
$con = mysql_connect("localhost","alvar6_iprograme","Drako521") or die (mysql_error()); 
mysql_select_db("alvar6_iprogramer",$con) or die (mysql_error()); 
?>