<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_admin = "localhost";
$database_admin = "CTOS2";
$username_admin = "isabelmejia222";
$password_admin = "Sandraisabel22";
$admin = mysql_connect($hostname_admin, $username_admin, $password_admin) or trigger_error(mysql_error(),E_USER_ERROR); 
?>