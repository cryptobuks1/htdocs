<h2>Add New Menu</h2>
<form method="post" action="<?php echo site_url('menu_group.add'); ?>">
	<p>
		<label for="menu-group-title">Title</label>
		<input type="text" name="title" id="menu-group-title">
	</p>
</form>